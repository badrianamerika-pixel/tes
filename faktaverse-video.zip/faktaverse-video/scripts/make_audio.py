"""
Generates the ORIGINAL (rights-free) music bed and sound effects used by the project.
Everything is synthesised from scratch with numpy, so there is nothing copyrighted.
Not needed for rendering - the generated files are already in public/audio.
Usage: python3 scripts/make_audio.py   (needs numpy + scipy + ffmpeg)
"""
import numpy as np, subprocess, os
from scipy.io import wavfile

SR = 44100
rng = np.random.default_rng(7)
OUT = os.path.join(os.path.dirname(__file__), "..", "public", "audio")
os.makedirs(OUT, exist_ok=True)

def t_(d): return np.arange(int(SR * d)) / SR
def env(n, a=0.002, d=0.2):
    t = np.arange(n) / SR
    return np.minimum(1, t / max(a, 1e-4)) * np.exp(-t / d)
def lp(x, k):  # simple one-pole low-pass
    y = np.zeros_like(x); s = 0.0
    for i, v in enumerate(x):
        s += k * (v - s); y[i] = s
    return y
def hp(x, k): return x - lp(x, k)
def put(buf, snd, at):
    i = int(at * SR)
    if i >= len(buf): return
    j = min(len(buf), i + len(snd))
    buf[i:j] += snd[: j - i]

def kick():
    t = t_(0.28); f = 45 + 110 * np.exp(-t * 30)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.001, 0.09) * 1.0
def clap():
    n = hp(rng.standard_normal(int(SR * 0.2)), 0.35)
    e = env(len(n), 0.001, 0.05)
    return n * e * 0.55
def hat(v=1.0):
    n = hp(rng.standard_normal(int(SR * 0.06)), 0.7)
    return n * env(len(n), 0.0005, 0.012) * 0.22 * v
def bass(f):
    t = t_(0.46)
    w = np.sin(2*np.pi*f*t) + 0.35*np.sin(2*np.pi*2*f*t)
    return np.tanh(w * 1.6) * env(len(t), 0.004, 0.22) * 0.55
def pluck(f):
    t = t_(0.2)
    w = 2*np.abs(2*((f*t) % 1) - 1) - 1  # triangle
    return w * env(len(t), 0.002, 0.07) * 0.16

# ---------- music (120 BPM, 36+ beats of A minor) ----------
BPM = 120; beat = 60 / BPM
DUR = 21.5
m = np.zeros(int(SR * DUR))
bass_notes = [55.0, 55.0, 65.41, 49.0]  # A1 A1 C2 G1
arp = [220.0, 261.63, 329.63, 392.0, 329.63, 261.63, 293.66, 349.23]
total_beats = int(DUR / beat)
for b in range(total_beats):
    tt = b * beat
    if not (4 <= b < 5):  # tiny drop-out for contrast at beat 4
        put(m, kick(), tt)
    if b % 2 == 1: put(m, clap(), tt)
    put(m, hat(0.7), tt); put(m, hat(1.0), tt + beat / 2)
    put(m, hat(0.5), tt + beat / 4); put(m, hat(0.5), tt + beat * 3 / 4)
    put(m, bass(bass_notes[(b // 1) % 4]), tt)
    for k in range(4):
        put(m, pluck(arp[(b * 4 + k) % len(arp)]), tt + k * beat / 4)
# riser before the outro (beats 32 -> 36)
rs = int(SR * 4 * beat); rt = np.arange(rs) / SR
riser = hp(rng.standard_normal(rs), 0.15) * (rt / rt[-1]) ** 2 * 0.28
put(m, riser, 32 * beat)
m = m / np.max(np.abs(m)) * 0.85
fi = int(SR * 0.15); fo = int(SR * 1.0)
m[:fi] *= np.linspace(0, 1, fi); m[-fo:] *= np.linspace(1, 0, fo)
wavfile.write("/tmp/music.wav", SR, (m * 32767).astype(np.int16))
subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", "/tmp/music.wav", "-b:a", "192k", os.path.join(OUT, "music.mp3")], check=True)

# ---------- sfx ----------
def save(name, x):
    x = x / max(1e-9, np.max(np.abs(x))) * 0.9
    wavfile.write(os.path.join(OUT, name), SR, (x * 32767).astype(np.int16))

# whoosh
n = int(SR * 0.55); t = np.arange(n) / SR
noise = rng.standard_normal(n)
k = 0.02 + 0.5 * (t / t[-1]) ** 2
y = np.zeros(n); s = 0.0
for i in range(n):
    s += k[i] * (noise[i] - s); y[i] = s
y = hp(y, 0.01) * np.sin(np.pi * t / t[-1]) ** 1.5
save("whoosh.wav", y)

# impact
t = t_(0.9)
f = 38 + 90 * np.exp(-t * 18)
boom = np.sin(2*np.pi*np.cumsum(f)/SR) * np.exp(-t * 4.5)
crack = lp(rng.standard_normal(len(t)), 0.3) * np.exp(-t * 30) * 0.9
save("impact.wav", boom + crack)

# glitch
parts = []
for i in range(7):
    d = int(SR * rng.uniform(0.02, 0.06)); tt = np.arange(d) / SR
    fr = rng.choice([180, 420, 900, 1700, 2600])
    sq = np.sign(np.sin(2*np.pi*fr*tt)) * 0.5
    sq = np.round(sq * 3) / 3
    parts.append(sq * (rng.standard_normal(d) * 0.3 + 0.8))
    parts.append(np.zeros(int(SR * 0.008)))
save("glitch.wav", np.concatenate(parts))

# pop
t = t_(0.12); f = 500 + 900 * (t / t[-1])
save("pop.wav", np.sin(2*np.pi*np.cumsum(f)/SR) * env(len(t), 0.001, 0.035))
print("audio done")
