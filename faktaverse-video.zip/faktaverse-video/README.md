# FAKTAVERSE – completed video project (Remotion)

A finished 9:16 edit (1080×1920, 30 fps, ~18 s, H.264 + AAC) built from your 10 photos and styled after your reference video.
All editing decisions are already encoded in `src/` – you only render it.

## Render in GitHub Codespaces
1. Create a new GitHub repo, upload the **contents** of this folder (not node_modules), open a Codespace.
2. `npm install`   (this also creates `package-lock.json`)
3. Preview (optional): `npm run preview`
4. Render: `npm run render`  →  `out/faktaverse-final.mp4`

If Chrome fails to start on Linux, run once:
```
sudo apt-get update && sudo apt-get install -y libnss3 libdbus-1-3 libatk1.0-0 libgbm-dev libasound2t64 libxrandr2 libxkbcommon-dev libxfixes3 libxcomposite1 libxdamage1 libatk-bridge2.0-0 libpango-1.0-0 libcairo2 libcups2
```
(Use `libasound2` instead of `libasound2t64` on older Ubuntu.) Remotion 4 bundles its own FFmpeg, so no separate FFmpeg install is needed.
Quick check of one frame: `npm run still` → `out/test-frame.png`.

## The edit (every cut lands on a beat of your music, ~138 BPM)
| # | Scene | Layout | Transition in |
|---|-------|--------|---------------|
| 1 | hook | full-screen punch zoom, shake, RGB split | – |
| 2 | collage | 3 tilted cards on sunburst + red tags | flash |
| 3 | type | full-screen kinetic typography + marquee ribbons | whip (motion blur) |
| 4 | night | cinematic slow push-in, teal grade | glitch |
| 5 | split | two diagonal panels | whip |
| 6 | floating | layered floating cards | zoom-blur |
| 7 | closeup | parallax zoom-out portrait | flash |
| 8 | poster | poster layout on red disc | glitch |
| 9 | outro | all 10 photos grid → title slam → fade out | zoom-blur |

## Things you may want to change
* **Text** – the on-screen words are neutral hype words (no facts were invented). Edit them in `src/scenes/Scenes.tsx`.
* **Timing / cuts / sound cues** – `src/config.ts` (`SCENE_LIST`, `SFX`).
* **Photo cropping** – `IMG` in `src/config.ts` (focus point + zoom per photo). Photo 8 is zoomed so the Timemark stamp with the location/address is not visible; photo 5 is zoomed to the face.
* **Audio** – `public/audio/music.mp3` is the track you supplied. The sound effects are original, synthesised by `scripts/make_audio.py` (that script also writes a placeholder music.mp3 - don't re-run it or it will overwrite yours). If you change the track, adjust `MUSIC_BPM` / `MUSIC_START_FRAME` in `src/theme.ts`. No narration was supplied, so there is no ducking.
* Font: Anton (SIL Open Font License, `public/fonts/`).
