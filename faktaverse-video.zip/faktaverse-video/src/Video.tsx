import React, {useEffect, useState} from 'react';
import {AbsoluteFill, Audio, Sequence, continueRender, delayRender, interpolate, staticFile} from 'remotion';
import {ColorFilters, FilmOverlay, TransitionWrap} from './components/Fx';
import {SFX, TIMELINE, TOTAL_FRAMES} from './config';
import {SCENE_COMPONENTS} from './scenes';
import {MUSIC_START_FRAME, OVERLAP} from './theme';

const useFonts = () => {
  const [handle] = useState(() => delayRender('Loading fonts'));
  useEffect(() => {
    const font = new FontFace('Anton', `url(${staticFile('fonts/Anton-Regular.ttf')})`);
    font
      .load()
      .then((loaded) => {
        document.fonts.add(loaded);
        continueRender(handle);
      })
      .catch(() => continueRender(handle));
  }, [handle]);
};

export const Video: React.FC = () => {
  useFonts();
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <ColorFilters />

      {/* Picture: each scene stays OVERLAP frames under the next so transitions have something to reveal */}
      {TIMELINE.map((s, i) => {
        const Scene = SCENE_COMPONENTS[s.id];
        const last = i === TIMELINE.length - 1;
        return (
          <Sequence key={s.id} from={s.start} durationInFrames={s.dur + (last ? 0 : OVERLAP)}>
            <TransitionWrap type={s.transition}>
              <Scene />
            </TransitionWrap>
          </Sequence>
        );
      })}

      <FilmOverlay />

      {/* Sound: supplied music (starts at its first beat) with fade in/out (no narration supplied, so no ducking is needed) */}
      <Audio
        src={staticFile('audio/music.mp3')}
        startFrom={MUSIC_START_FRAME}
        volume={(f) =>
          interpolate(f, [0, 6, TOTAL_FRAMES - 24, TOTAL_FRAMES], [0, 0.8, 0.8, 0], {
            extrapolateLeft: 'clamp',
            extrapolateRight: 'clamp',
          })
        }
      />
      {SFX.map((e, i) => (
        <Sequence key={i} from={Math.max(0, e.frame)} durationInFrames={60}>
          <Audio src={staticFile(`audio/${e.file}`)} volume={e.volume} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
