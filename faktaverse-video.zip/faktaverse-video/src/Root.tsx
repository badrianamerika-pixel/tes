import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {TOTAL_FRAMES} from './config';
import {FPS, H, W} from './theme';

export const Root: React.FC = () => {
  return (
    <Composition
      id="Faktaverse"
      component={Video}
      durationInFrames={TOTAL_FRAMES}
      fps={FPS}
      width={W}
      height={H}
    />
  );
};
