import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {Photo} from './Photo';

type Props = {
  id: string;
  x: number; // centre
  y: number;
  w: number;
  h: number;
  rot: number;
  delay?: number;
  from?: 'left' | 'right' | 'top' | 'bottom';
  scale?: number;
  z?: number;
};

/** White-bordered photo card that flies in with a bounce and then floats. */
export const Card: React.FC<Props> = ({id, x, y, w, h, rot, delay = 0, from = 'bottom', scale = 1, z = 1}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const f = frame - delay;
  const s = spring({frame: f, fps, config: {damping: 11, stiffness: 150, mass: 0.8}});
  const k = 1 - s;
  const ox = from === 'left' ? -1500 * k : from === 'right' ? 1500 * k : 0;
  const oy = from === 'top' ? -1700 * k : from === 'bottom' ? 1700 * k : 0;
  const spin = (from === 'left' || from === 'top' ? -1 : 1) * 28 * k;
  const floatY = f > 0 ? Math.sin((frame + delay * 3) / 14) * 10 : 0;
  const wob = f > 0 ? Math.sin(frame / 20 + delay) * 1.2 : 0;
  return (
    <div
      style={{
        position: 'absolute',
        left: x - w / 2,
        top: y - h / 2,
        width: w,
        height: h,
        zIndex: z,
        boxSizing: 'border-box',
        padding: 14,
        background: '#fff',
        borderRadius: 22,
        boxShadow: '0 30px 60px rgba(0,0,0,0.45)',
        transform: `translate(${ox}px, ${oy + floatY}px) rotate(${rot + spin + wob}deg)`,
        opacity: f < 0 ? 0 : 1,
      }}
    >
      <div style={{position: 'relative', width: '100%', height: '100%', overflow: 'hidden', borderRadius: 10}}>
        <Photo id={id} scale={scale} />
      </div>
    </div>
  );
};
