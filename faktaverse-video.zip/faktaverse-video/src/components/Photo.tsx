import React from 'react';
import {Img, staticFile} from 'remotion';
import {IMG} from '../config';

type Props = {
  id: string; // p01 ... p10
  scale?: number; // animated extra zoom, multiplied with the per-photo crop zoom
  fx?: number;
  fy?: number;
  tx?: number;
  ty?: number;
  grade?: string; // CSS filter (colour grading)
};

/** Fills its parent, crops with object-fit: cover around a focus point. */
export const Photo: React.FC<Props> = ({id, scale = 1, fx, fy, tx = 0, ty = 0, grade}) => {
  const d = IMG[id];
  const x = fx ?? d.fx;
  const y = fy ?? d.fy;
  return (
    <div style={{position: 'absolute', left: 0, top: 0, right: 0, bottom: 0, overflow: 'hidden'}}>
      <Img
        src={staticFile(`images/${id}.jpg`)}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          objectPosition: `${x}% ${y}%`,
          transformOrigin: `${x}% ${y}%`,
          transform: `translate(${tx}px, ${ty}px) scale(${d.zoom * scale})`,
          filter: grade,
        }}
      />
    </div>
  );
};
