import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {FONT, W} from '../theme';

export type Word = {t: string; color?: string; stroke?: string};

type Props = {
  words: Word[];
  y: number; // vertical centre
  size: number;
  stagger?: number;
  delay?: number;
  rot?: number;
  strokeW?: number;
  lineH?: number;
  row?: boolean;
};

/** Word-by-word bounce-in typography with thick outline and hard shadow. */
export const KineticText: React.FC<Props> = ({
  words,
  y,
  size,
  stagger = 4,
  delay = 0,
  rot = 0,
  strokeW = 14,
  lineH = 0.95,
  row = false,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        top: y,
        width: W,
        zIndex: 60,
        display: 'flex',
        flexDirection: row ? 'row' : 'column',
        flexWrap: row ? 'wrap' : 'nowrap',
        alignItems: 'center',
        justifyContent: 'center',
        gap: row ? 24 : 0,
        transform: `translateY(-50%) rotate(${rot}deg)`,
      }}
    >
      {words.map((w, i) => {
        const f = frame - delay - i * stagger;
        const s = spring({frame: f, fps, config: {damping: 9, stiffness: 220, mass: 0.6}});
        const idle = f > 10 ? 1 + 0.02 * Math.sin(frame / 6 + i) : 1;
        return (
          <div
            key={i}
            style={{
              fontFamily: FONT,
              fontSize: size,
              lineHeight: lineH,
              letterSpacing: 2,
              textTransform: 'uppercase',
              color: w.color ?? '#fff',
              WebkitTextStroke: `${strokeW}px ${w.stroke ?? '#000'}`,
              paintOrder: 'stroke fill',
              textShadow: '0 14px 0 rgba(0,0,0,0.55)',
              opacity: f < 0 ? 0 : 1,
              transform: `translateY(${(1 - s) * 90}px) scale(${(0.3 + 0.7 * s) * idle}) rotate(${(1 - s) * -6}deg)`,
              whiteSpace: 'nowrap',
            }}
          >
            {w.t}
          </div>
        );
      })}
    </div>
  );
};
