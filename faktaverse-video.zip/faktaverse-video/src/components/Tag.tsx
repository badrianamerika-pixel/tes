import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {FONT, RED} from '../theme';

type Props = {
  text: string;
  x: number;
  y: number;
  rot?: number;
  delay?: number;
  size?: number;
  bg?: string;
  color?: string;
};

/** Red label sticker (like the tags in the reference). */
export const Tag: React.FC<Props> = ({text, x, y, rot = 0, delay = 0, size = 76, bg = RED, color = '#fff'}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const f = frame - delay;
  const s = spring({frame: f, fps, config: {damping: 8, stiffness: 260, mass: 0.5}});
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        zIndex: 50,
        transform: `translate(-50%, -50%) rotate(${rot}deg) scale(${s})`,
        opacity: f < 0 ? 0 : 1,
        background: bg,
        color,
        fontFamily: FONT,
        fontSize: size,
        lineHeight: 1,
        letterSpacing: 2,
        padding: '12px 30px 8px',
        whiteSpace: 'nowrap',
        boxShadow: '8px 8px 0 rgba(0,0,0,0.85)',
        textTransform: 'uppercase',
      }}
    >
      {text}
    </div>
  );
};
