import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {FONT, H, W, beatPulse} from '../theme';
import type {TransitionType} from '../config';

/** Camera shake with decay. Deterministic (pure functions of the frame). */
export const Shake: React.FC<{amp?: number; start?: number; dur?: number; children: React.ReactNode}> = ({
  amp = 16,
  start = 0,
  dur = 10,
  children,
}) => {
  const frame = useCurrentFrame();
  const t = frame - start;
  const k = t < 0 || t > dur ? 0 : 1 - t / dur;
  const dx = Math.sin(frame * 47.3) * amp * k;
  const dy = Math.cos(frame * 39.1) * amp * k;
  const r = Math.sin(frame * 23.7) * amp * 0.04 * k;
  return <AbsoluteFill style={{transform: `translate(${dx}px, ${dy}px) rotate(${r}deg)`}}>{children}</AbsoluteFill>;
};

/** Channel-separated RGB split. Needs <ColorFilters/> mounted once. */
export const RgbSplit: React.FC<{amount: number; children: React.ReactNode}> = ({amount, children}) => {
  if (amount < 0.5) return <AbsoluteFill>{children}</AbsoluteFill>;
  const layer = (id: string, dx: number) => (
    <AbsoluteFill style={{filter: `url(#${id})`, transform: `translateX(${dx}px)`, mixBlendMode: 'screen'}}>
      {children}
    </AbsoluteFill>
  );
  return (
    <AbsoluteFill style={{background: '#000', isolation: 'isolate'}}>
      {layer('chR', amount)}
      {layer('chG', 0)}
      {layer('chB', -amount)}
    </AbsoluteFill>
  );
};

export const ColorFilters: React.FC = () => (
  <svg width={0} height={0} style={{position: 'absolute'}}>
    <defs>
      <filter id="chR" colorInterpolationFilters="sRGB">
        <feColorMatrix type="matrix" values="1 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0" />
      </filter>
      <filter id="chG" colorInterpolationFilters="sRGB">
        <feColorMatrix type="matrix" values="0 0 0 0 0  0 1 0 0 0  0 0 0 0 0  0 0 0 1 0" />
      </filter>
      <filter id="chB" colorInterpolationFilters="sRGB">
        <feColorMatrix type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 1 0 0  0 0 0 1 0" />
      </filter>
    </defs>
  </svg>
);

const GlitchBars: React.FC<{frame: number}> = ({frame}) => (
  <>
    {[0, 1, 2, 3].map((i) => {
      const y = (frame * 131 + i * 377) % 1800;
      const h = 30 + ((i * 53 + frame * 17) % 90);
      const dx = Math.sin(frame * 3.3 + i) * 60;
      return (
        <div
          key={i}
          style={{
            position: 'absolute',
            left: 0,
            top: y,
            width: W,
            height: h,
            background: i % 2 ? 'rgba(0,255,255,0.5)' : 'rgba(255,0,60,0.5)',
            mixBlendMode: 'screen',
            transform: `translateX(${dx}px)`,
          }}
        />
      );
    })}
  </>
);

/** Incoming-scene transition: flash / whip (motion blur slide) / glitch / zoom-blur. */
export const TransitionWrap: React.FC<{type: TransitionType; children: React.ReactNode}> = ({type, children}) => {
  const frame = useCurrentFrame();
  const len = 8;
  const p = interpolate(frame, [0, len], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  let style: React.CSSProperties = {};
  if (frame < len) {
    if (type === 'whip') {
      style = {transform: `translateX(${(1 - p) * W}px) skewX(${-(1 - p) * 10}deg)`, filter: `blur(${(1 - p) * 28}px)`};
    } else if (type === 'zoom') {
      style = {
        transform: `scale(${1 + (1 - p) * 0.6})`,
        filter: `blur(${(1 - p) * 18}px)`,
        opacity: interpolate(frame, [0, 4], [0, 1], {extrapolateRight: 'clamp'}),
      };
    } else if (type === 'glitch') {
      style = {
        transform: `translateX(${Math.sin(frame * 9.1) * 40 * (1 - p)}px)`,
        filter: `hue-rotate(${(1 - p) * 90}deg) saturate(${1 + (1 - p)})`,
      };
    }
  }
  return (
    <AbsoluteFill>
      <AbsoluteFill style={style}>{children}</AbsoluteFill>
      {type === 'flash' && (
        <AbsoluteFill
          style={{background: '#fff', opacity: interpolate(frame, [0, 1, 8], [1, 0.9, 0], {extrapolateRight: 'clamp'})}}
        />
      )}
      {type === 'glitch' && frame < len && <GlitchBars frame={frame} />}
    </AbsoluteFill>
  );
};

/** Rotating sunburst + pulsing blue rings (reference-style backdrop). */
export const Sunburst: React.FC<{c1: string; c2: string; ring?: string; cy?: number}> = ({
  c1,
  c2,
  ring = '#1f6bff',
  cy = 45,
}) => {
  const frame = useCurrentFrame();
  const pulse = beatPulse(frame);
  const mask = `radial-gradient(circle at 50% ${cy}%, #000 0%, transparent 65%)`;
  return (
    <AbsoluteFill>
      <AbsoluteFill
        style={{
          background: `repeating-conic-gradient(from ${frame * 0.7}deg at 50% ${cy}%, ${c1} 0deg 12deg, ${c2} 12deg 24deg)`,
        }}
      />
      <AbsoluteFill
        style={{
          background: `repeating-radial-gradient(circle at 50% ${cy}%, ${ring} 0px 34px, transparent 34px 80px)`,
          WebkitMaskImage: mask,
          maskImage: mask,
          transform: `scale(${1 + 0.05 * pulse})`,
          opacity: 0.9,
        }}
      />
    </AbsoluteFill>
  );
};

/** Scrolling text ribbon. */
export const Marquee: React.FC<{
  text: string;
  y: number;
  dir?: 1 | -1;
  bg?: string;
  color?: string;
  size?: number;
}> = ({text, y, dir = 1, bg = '#000', color = '#fff', size = 54}) => {
  const frame = useCurrentFrame();
  const unit = 760;
  const off = (frame * 14) % unit;
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        top: y,
        width: W,
        height: size + 36,
        overflow: 'hidden',
        background: bg,
        zIndex: 40,
        transform: `rotate(${dir === 1 ? -3 : 3}deg) scale(1.1)`,
      }}
    >
      <div style={{display: 'flex', transform: `translateX(${dir === 1 ? -off : off - unit}px)`}}>
        {Array.from({length: 6}).map((_, i) => (
          <div
            key={i}
            style={{
              width: unit,
              flexShrink: 0,
              textAlign: 'center',
              fontFamily: FONT,
              fontSize: size,
              lineHeight: `${size + 36}px`,
              color,
              letterSpacing: 4,
              whiteSpace: 'nowrap',
            }}
          >
            {text}
          </div>
        ))}
      </div>
    </div>
  );
};

/** Film grain + vignette, mounted once above everything. */
export const FilmOverlay: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <>
      <AbsoluteFill
        style={{
          background: 'radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,0.5) 100%)',
          pointerEvents: 'none',
        }}
      />
      <svg
        width={W}
        height={H}
        style={{position: 'absolute', left: 0, top: 0, opacity: 0.1, mixBlendMode: 'overlay', pointerEvents: 'none'}}
      >
        <filter id="grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 9} />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" />
      </svg>
    </>
  );
};
