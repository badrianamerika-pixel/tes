import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {Card} from '../components/Card';
import {Marquee, RgbSplit, Shake, Sunburst} from '../components/Fx';
import {KineticText} from '../components/Kinetic';
import {Photo} from '../components/Photo';
import {Tag} from '../components/Tag';
import {H, RED, W, beatPulse} from '../theme';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

/* 1 ─ HOOK: full-screen punch zoom + camera shake + RGB split */
export const SceneHook: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const punch = spring({frame, fps, config: {damping: 14, stiffness: 120}});
  const scale = interpolate(punch, [0, 1], [1.45, 1.05]) + frame * 0.0016;
  const split = interpolate(frame, [0, 10], [26, 0], clamp);
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Shake amp={22} dur={12}>
        <RgbSplit amount={split}>
          <Photo id="p02" scale={scale} grade="contrast(1.12) saturate(1.1)" />
        </RgbSplit>
      </Shake>
      <AbsoluteFill style={{background: 'linear-gradient(to top, rgba(0,0,0,0.88) 0%, rgba(0,0,0,0) 55%)'}} />
      <Tag text="Tonton sampai habis" x={540} y={250} rot={-4} delay={14} size={64} />
      <KineticText
        words={[{t: 'FAKTA'}, {t: 'VERSE', color: RED, stroke: '#fff'}]}
        y={1380}
        size={290}
        delay={4}
        stagger={6}
        strokeW={12}
      />
    </AbsoluteFill>
  );
};

/* 2 ─ COLLAGE: triple tilted cards on sunburst */
export const SceneCollage: React.FC = () => (
  <AbsoluteFill style={{background: '#f5f3ee'}}>
    <Sunburst c1="#ffb21a" c2="#ffd45e" />
    <Card id="p01" x={330} y={700} w={520} h={700} rot={-8} from="left" delay={0} z={1} />
    <Card id="p06" x={760} y={1000} w={480} h={640} rot={6} from="right" delay={5} z={2} />
    <Card id="p10" x={420} y={1430} w={520} h={420} rot={-3} from="bottom" delay={10} z={3} />
    <Tag text="Siap?" x={300} y={380} rot={-6} delay={8} size={96} />
    <Tag text="Gas!" x={820} y={640} rot={8} delay={13} size={96} />
    <Tag text="Lihat" x={740} y={1340} rot={-5} delay={18} size={80} />
  </AbsoluteFill>
);

/* 3 ─ TYPE: full-screen kinetic typography, one word per beat */
export const SceneType: React.FC = () => {
  const frame = useCurrentFrame();
  const pulse = beatPulse(frame);
  return (
    <AbsoluteFill style={{background: '#d90f1c'}}>
      <AbsoluteFill style={{opacity: 0.28, mixBlendMode: 'multiply'}}>
        <Photo id="p07" scale={1.15 + frame * 0.002} grade="grayscale(1) contrast(1.3)" />
      </AbsoluteFill>
      <AbsoluteFill
        style={{
          background: 'radial-gradient(circle at 50% 50%, rgba(255,255,255,0.2), transparent 60%)',
          transform: `scale(${1 + 0.08 * pulse})`,
        }}
      />
      <Marquee text="FAKTAVERSE  •  FAKTAVERSE  •" y={170} dir={1} />
      <Marquee text="FAKTAVERSE  •  FAKTAVERSE  •" y={1650} dir={-1} bg="#fff" color="#d90f1c" />
      <Shake amp={14} start={13} dur={6}>
        <Shake amp={14} start={26} dur={6}>
          <KineticText
            words={[{t: 'LIHAT'}, {t: 'LEBIH'}, {t: 'DEKAT', color: '#111', stroke: '#fff'}]}
            y={960}
            size={330}
            delay={3}
            stagger={13}
            strokeW={16}
          />
        </Shake>
      </Shake>
    </AbsoluteFill>
  );
};

/* 4 ─ NIGHT: cinematic slow push-in, teal grade, RGB split pulses */
export const SceneNight: React.FC = () => {
  const frame = useCurrentFrame();
  const scale = 1 + 0.35 * (frame / 65);
  const split = interpolate(frame % 26, [0, 6], [18, 0], clamp);
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Shake amp={8} dur={8}>
        <RgbSplit amount={split}>
          <Photo id="p04" scale={scale} grade="contrast(1.2) saturate(0.85) brightness(1.2)" />
        </RgbSplit>
      </Shake>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(10,30,70,0.35), rgba(0,0,0,0.25))'}} />
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.75) 100%)'}} />
      <KineticText words={[{t: 'SSSTT...', color: '#ff2d3a'}]} y={1450} size={230} delay={10} strokeW={12} />
    </AbsoluteFill>
  );
};

/* 5 ─ SPLIT: two diagonal panels sliding in from opposite sides */
export const SceneSplit: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const a = spring({frame, fps, config: {damping: 13, stiffness: 140}});
  const drift = 1 + frame * 0.0015;
  return (
    <AbsoluteFill style={{background: '#111'}}>
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          width: W,
          height: 1010,
          clipPath: 'polygon(0 0, 100% 0, 100% 88%, 0 100%)',
          transform: `translateX(${(1 - a) * -1100}px)`,
        }}
      >
        <Photo id="p09" scale={drift} grade="contrast(1.1)" />
      </div>
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 910,
          width: W,
          height: 1010,
          clipPath: 'polygon(0 12%, 100% 0, 100% 100%, 0 100%)',
          transform: `translateX(${(1 - a) * 1100}px)`,
        }}
      >
        <Photo id="p08" scale={drift} grade="contrast(1.1)" />
      </div>
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          width: W,
          height: H,
          background: '#fff',
          clipPath: 'polygon(0 1008px, 100% 886px, 100% 914px, 0 1036px)',
          opacity: a,
        }}
      />
      <KineticText
        words={[{t: 'BEDA'}, {t: 'GAYA', color: RED, stroke: '#fff'}]}
        y={960}
        size={230}
        delay={8}
        stagger={8}
        strokeW={12}
        rot={-4}
      />
    </AbsoluteFill>
  );
};

/* 6 ─ FLOATING: layered cards over rings */
export const SceneFloating: React.FC = () => (
  <AbsoluteFill style={{background: '#f7f7f5'}}>
    <Sunburst c1="#ffffff" c2="#ffe3b0" ring="#1f6bff" cy={50} />
    <Card id="p02" x={540} y={520} w={900} h={600} rot={-4} from="top" delay={0} z={1} />
    <Card id="p03" x={360} y={1130} w={640} h={460} rot={5} from="left" delay={6} z={2} />
    <Card id="p05" x={770} y={1390} w={440} h={560} rot={-7} from="right" delay={12} z={3} />
    <Tag text="Momen" x={250} y={250} rot={-8} delay={8} size={90} />
    <Tag text="Candid" x={820} y={880} rot={7} delay={14} size={90} />
    <Tag text="Nyata" x={330} y={1560} rot={-4} delay={20} size={90} />
  </AbsoluteFill>
);

/* 7 ─ CLOSE-UP: parallax zoom-out on a full-screen portrait */
export const SceneCloseup: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = interpolate(frame, [0, 52], [0, 1], clamp);
  const scale = 1.3 - 0.3 * ease;
  const split = interpolate(frame, [0, 6], [14, 0], clamp);
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <Shake amp={12} dur={8}>
        <RgbSplit amount={split}>
          <Photo id="p07" scale={scale} grade="contrast(1.15) saturate(1.05)" />
        </RgbSplit>
      </Shake>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at center, transparent 45%, rgba(0,0,0,0.7) 100%)'}} />
      <AbsoluteFill style={{background: 'linear-gradient(to top, rgba(0,0,0,0.8) 0%, transparent 45%)'}} />
      <KineticText
        words={[{t: 'TANPA'}, {t: 'FILTER', color: RED, stroke: '#fff'}]}
        y={1400}
        size={230}
        delay={6}
        stagger={8}
        strokeW={12}
      />
    </AbsoluteFill>
  );
};

/* 8 ─ POSTER: dynamic poster layout on a red disc */
export const ScenePoster: React.FC = () => {
  const frame = useCurrentFrame();
  const pulse = beatPulse(frame);
  return (
    <AbsoluteFill style={{background: '#111'}}>
      <div
        style={{
          position: 'absolute',
          left: W / 2 - 700,
          top: 940 - 700,
          width: 1400,
          height: 1400,
          borderRadius: 700,
          background: RED,
          transform: `scale(${1 + 0.04 * pulse})`,
        }}
      />
      <Card id="p10" x={600} y={960} w={700} h={960} rot={4} from="bottom" delay={0} z={1} />
      <Card id="p01" x={250} y={1400} w={360} h={500} rot={-10} from="left" delay={8} z={2} />
      <Card id="p09" x={850} y={1560} w={300} h={400} rot={8} from="right" delay={14} z={3} />
      <KineticText
        words={[{t: 'SEMUA'}, {t: 'BERMULA', color: RED, stroke: '#fff'}]}
        y={280}
        size={185}
        delay={2}
        stagger={7}
        strokeW={10}
        rot={-3}
      />
      <Tag text="Di sini" x={760} y={1370} rot={-6} delay={20} size={90} bg="#fff" color="#111" />
    </AbsoluteFill>
  );
};

/* 9 ─ OUTRO: all ten photos pop into a grid, then the title slams in */
const GRID: {id: string; x: number; y: number; rot: number}[] = [
  {id: 'p01', x: 200, y: 330, rot: -5},
  {id: 'p02', x: 540, y: 330, rot: 4},
  {id: 'p03', x: 880, y: 330, rot: -4},
  {id: 'p04', x: 200, y: 730, rot: 5},
  {id: 'p05', x: 540, y: 730, rot: -6},
  {id: 'p06', x: 880, y: 730, rot: 5},
  {id: 'p07', x: 200, y: 1130, rot: -4},
  {id: 'p08', x: 540, y: 1130, rot: 6},
  {id: 'p09', x: 880, y: 1130, rot: -5},
  {id: 'p10', x: 540, y: 1530, rot: 4},
];
export const SceneOutro: React.FC = () => {
  const frame = useCurrentFrame();
  const dark = interpolate(frame, [38, 46], [0, 0.65], clamp);
  const fade = interpolate(frame, [66, 78], [0, 1], clamp);
  return (
    <AbsoluteFill style={{background: '#f2f0ea'}}>
      <Sunburst c1="#ffffff" c2="#ffd45e" cy={40} />
      {GRID.map((g, i) => (
        <Card key={g.id} id={g.id} x={g.x} y={g.y} w={300} h={380} rot={g.rot} from="bottom" delay={i * 3} z={i + 1} />
      ))}
      <AbsoluteFill style={{background: `rgba(0,0,0,${dark})`, zIndex: 40}} />
      <Shake amp={20} start={42} dur={10}>
        <KineticText
          words={[{t: 'FAKTA'}, {t: 'VERSE', color: RED, stroke: '#fff'}]}
          y={880}
          size={320}
          delay={42}
          stagger={6}
          strokeW={14}
        />
      </Shake>
      <Tag text="Ikuti untuk lanjutan" x={540} y={1210} rot={-3} delay={55} size={70} />
      <AbsoluteFill style={{background: '#000', opacity: fade, zIndex: 100}} />
    </AbsoluteFill>
  );
};
