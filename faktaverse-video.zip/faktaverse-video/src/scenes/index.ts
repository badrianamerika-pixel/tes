import React from 'react';
import {
  SceneCloseup,
  SceneCollage,
  SceneFloating,
  SceneHook,
  SceneNight,
  ScenePoster,
  SceneOutro,
  SceneSplit,
  SceneType,
} from './Scenes';

export const SCENE_COMPONENTS: Record<string, React.FC> = {
  hook: SceneHook,
  collage: SceneCollage,
  type: SceneType,
  night: SceneNight,
  split: SceneSplit,
  floating: SceneFloating,
  closeup: SceneCloseup,
  poster: ScenePoster,
  outro: SceneOutro,
};
