import {BEAT} from './theme';

/**
 * Per-photo framing. fx/fy = focus point (percent) so the face stays visible when a
 * landscape photo is cropped to 9:16. zoom > 1 also crops away unwanted edges
 * (watermark / address stamp on p08, hand on p05).
 */
export const IMG: Record<string, {fx: number; fy: number; zoom: number}> = {
  p01: {fx: 48, fy: 40, zoom: 1},
  p02: {fx: 74, fy: 40, zoom: 1},
  p03: {fx: 55, fy: 45, zoom: 1},
  p04: {fx: 50, fy: 48, zoom: 1},
  p05: {fx: 48, fy: 30, zoom: 2.4},
  p06: {fx: 48, fy: 45, zoom: 1},
  p07: {fx: 50, fy: 40, zoom: 1},
  p08: {fx: 50, fy: 25, zoom: 1.7},
  p09: {fx: 50, fy: 45, zoom: 1},
  p10: {fx: 70, fy: 45, zoom: 1},
};

export type TransitionType = 'none' | 'flash' | 'whip' | 'glitch' | 'zoom';

export type SceneDef = {id: string; beats: number; transition: TransitionType};

/** The finished edit: 9 scenes, every cut lands on a beat of the music (138 BPM). */
export const SCENE_LIST: SceneDef[] = [
  {id: 'hook', beats: 4, transition: 'none'},
  {id: 'collage', beats: 5, transition: 'flash'},
  {id: 'type', beats: 4, transition: 'whip'},
  {id: 'night', beats: 5, transition: 'glitch'},
  {id: 'split', beats: 4, transition: 'whip'},
  {id: 'floating', beats: 5, transition: 'zoom'},
  {id: 'closeup', beats: 4, transition: 'flash'},
  {id: 'poster', beats: 5, transition: 'glitch'},
  {id: 'outro', beats: 6, transition: 'zoom'},
];

export type TimedScene = SceneDef & {start: number; dur: number};

export const TIMELINE: TimedScene[] = (() => {
  let beats = 0;
  return SCENE_LIST.map((s) => {
    const start = Math.round(beats * BEAT);
    beats += s.beats;
    const dur = Math.round(beats * BEAT) - start;
    return {...s, start, dur};
  });
})();

export const TOTAL_FRAMES = TIMELINE.reduce((a, s) => a + s.dur, 0); // 548 = ~18.3 s

const at = (id: string) => TIMELINE.find((s) => s.id === id)!.start;

/** Sound-effect cue sheet (absolute frames). Files live in public/audio. */
export const SFX: {file: string; frame: number; volume: number}[] = [
  {file: 'impact.wav', frame: 0, volume: 0.9},
  {file: 'glitch.wav', frame: 0, volume: 0.5},
  {file: 'impact.wav', frame: at('collage'), volume: 0.8},
  {file: 'pop.wav', frame: at('collage') + 8, volume: 0.7},
  {file: 'pop.wav', frame: at('collage') + 13, volume: 0.7},
  {file: 'pop.wav', frame: at('collage') + 18, volume: 0.7},
  {file: 'whoosh.wav', frame: at('type') - 4, volume: 0.8},
  {file: 'impact.wav', frame: at('type') + 3, volume: 0.7},
  {file: 'impact.wav', frame: at('type') + 16, volume: 0.7},
  {file: 'impact.wav', frame: at('type') + 29, volume: 0.7},
  {file: 'glitch.wav', frame: at('night'), volume: 0.8},
  {file: 'glitch.wav', frame: at('night') + 30, volume: 0.5},
  {file: 'whoosh.wav', frame: at('split') - 4, volume: 0.8},
  {file: 'impact.wav', frame: at('split') + 6, volume: 0.6},
  {file: 'whoosh.wav', frame: at('floating') - 4, volume: 0.6},
  {file: 'pop.wav', frame: at('floating') + 8, volume: 0.7},
  {file: 'pop.wav', frame: at('floating') + 14, volume: 0.7},
  {file: 'pop.wav', frame: at('floating') + 20, volume: 0.7},
  {file: 'impact.wav', frame: at('closeup'), volume: 0.9},
  {file: 'glitch.wav', frame: at('poster'), volume: 0.8},
  {file: 'pop.wav', frame: at('poster') + 6, volume: 0.7},
  {file: 'whoosh.wav', frame: at('outro') - 4, volume: 0.8},
  {file: 'impact.wav', frame: at('outro') + 42, volume: 1},
  {file: 'pop.wav', frame: at('outro') + 55, volume: 0.7},
];
