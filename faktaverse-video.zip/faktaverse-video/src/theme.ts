export const W = 1080;
export const H = 1920;
export const FPS = 30;
export const MUSIC_BPM = 138; // measured from the supplied track (beat phase ~0.145 s)
export const BEAT = (FPS * 60) / MUSIC_BPM; // ~13.04 frames per beat
export const MUSIC_START_FRAME = 4; // skip 4 frames of the track so its first beat lands on frame 0
export const OVERLAP = 8; // frames a scene stays under the next one (for transitions)

export const RED = '#e60f1f';
export const WHITE = '#ffffff';
export const BLACK = '#0b0b0b';
export const FONT = "'Anton','Impact','Arial Black',sans-serif";

/** 1 on the beat, decaying to 0 until the next beat */
export const beatPulse = (frame: number): number => 1 - (frame % BEAT) / BEAT;
